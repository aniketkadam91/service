'use client';
import React from 'react';
import classes from './register.module.css'
import Button from '../component/Button';
import Input from '../component/Input';

function Register(props) {

    //const [valid, setValid] = React.useState(true);
    const [errormessage, setMessage] = React.useState("");
    const [errormessageconfirm, setErrormessageconfirm] = React.useState("");

    const handleSubmit = (e) =>{
        e.preventDefault();
        const fd = new FormData(e.target);
        const enterdEmail = fd.get("email");
        const enterdPassword = fd.get("psw");
        const firstname = fd.get("firstname");
        const lastname = fd.get("lastname");
        const confirm = fd.get("psw-repeat");
        
        if(enterdPassword.length < 8 || enterdPassword.length > 16 ){
            setMessage("Password must be between 8 to 15 characters");
            //setValid(false);
            return;
        }else{
            setMessage("");
        }
        
        if(enterdPassword !== confirm){
            //setMessage("Password not matching");
            setErrormessageconfirm("Password not matching");
            //setValid(false);
            return;
        }
        else{
            setErrormessageconfirm("");
        }
        
        // console.log(enterdEmail);
        // console.log(enterdPassword);
        // console.log(enterdEmail, enterdPassword);
        e.target.reset();
    }

    return (
        <>
            <div className={classes.form_section}>
                <h1 className={classes.header}>
                    Register Here 
                </h1>
                <form onSubmit={handleSubmit}>
                    <div className={classes.form_container}>                                
                        <Input className="input_wrapper" type="text" placeholder="First Name" name="firstname" required={false}>First Name</Input>       
                        <Input className="input_wrapper" type="text" placeholder="Last Name" name="lastname" required={false}>Last Name</Input>
                        <Input className="input_wrapper" type="email" placeholder="Enter Email" name="email" required={true}>Enter Email</Input>
                        <Input className="input_wrapper" errormessage={errormessage} type="password" placeholder="Enter Password" name="psw" required={true}>Enter Password</Input>
                        <Input className="input_wrapper" errormessageconfirm={errormessageconfirm} type="password" placeholder="Confirm Password" name="psw-repeat" required={true}>Confirm Password</Input>
                        <Button type="submit" className="registerbtn" > Register</Button>
                    </div>
                </form>
            </div>
        </>
    );
}

export default Register;
'use client';
import React from 'react';
import Input from '../component/Input';
import Button from '../component/Button';
import classes from './login.module.css'

function Login(props) {

    const handleSubmit = (e) =>{
        e.preventDefault();
        const fd = new FormData(e.target);
        const enterdEmail = fd.get("email");
        const enterdPassword = fd.get("psw");
        e.target.reset();
    }
    return (
        <div className={classes.login_form}>
             <h1 className={classes.header}>
                Login 
            </h1>
            <form onSubmit={handleSubmit}>
                <div className={classes.form_container}>                                
                    <Input className="input_wrapper" type="email" placeholder="Enter Email" name="email" required={true}>Enter Email</Input>
                    <Input className="input_wrapper" type="password" placeholder="Enter Password" name="psw" required={true}>Enter Password</Input>               
                    <Button type="submit" className="registerbtn" > Login</Button>
                </div>
            </form>
        </div>
    );
}

export default Login;
import Link from 'next/link';
import React from 'react';
import classes from './header.module.css';

function Navigation(props) {
    return (
        <>
            <header className={classes.header}>
                <Link className={classes.logo} href="/">NextApp</Link>          
                <nav className={classes.nav}>
                    <ul>
                        <li>
                            <Link href="/register">Register</Link>
                        </li>
                        <li>
                            <Link href="/login">Login</Link>
                        </li>   
                    </ul>
                </nav>
            </header>
            
        </>
    );
}

export default Navigation;